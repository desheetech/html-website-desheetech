var app = angular.module('myApp', ['ngRoute']);

app.config(function($routeProvider) {
    $routeProvider
    .when('/', {
        templateUrl: 'pages/home.html'
    })
    .when('/about', {
        templateUrl: 'pages/about.html'
    })
    .when('/services', {
        templateUrl: 'pages/services.html'
    })
    .when('/contact', {
        templateUrl: 'pages/contact.html'
    })
    .otherwise({
        redirectTo: '/'
    });
});

app.controller('MainController', function() {
    // Main Controller logic can go here
});
