let slider = document.querySelector('.slider');
let slides = document.querySelectorAll('.slide');
let currentIndex = 0;
let slideWidth = slides[0].clientWidth;

function nextSlide() {
    currentIndex++;
    if (currentIndex >= slides.length) {
        currentIndex = 0;
    }
    updateSlidePosition();
}

function updateSlidePosition() {
    let newPosition = -currentIndex * slideWidth;
    slider.style.transform = `translateX(${newPosition}px)`;
}

setInterval(nextSlide, 3000); // यहां आप विचलन की धीमाई सेट कर सकते हैं
